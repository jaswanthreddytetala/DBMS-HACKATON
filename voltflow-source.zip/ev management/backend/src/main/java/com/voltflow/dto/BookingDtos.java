package com.voltflow.dto;
import jakarta.validation.constraints.NotNull; import java.time.Instant;
public final class BookingDtos { private BookingDtos(){} public record CreateBooking(@NotNull Long chargerId,@NotNull Instant scheduledAt){} public record StartSession(@NotNull Long bookingId){} public record StopSession(@NotNull java.math.BigDecimal energyKwh){} }
