package com.voltflow.repository;
import com.voltflow.entity.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface SessionRepository extends JpaRepository<ChargingSession,Long> { List<ChargingSession> findByDriverIdOrderByStartedAtDesc(Long driverId); long countByStatus(SessionStatus status); }
