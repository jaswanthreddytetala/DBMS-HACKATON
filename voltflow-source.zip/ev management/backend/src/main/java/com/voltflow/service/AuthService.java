package com.voltflow.service;
import com.voltflow.dto.AuthDtos.*; import com.voltflow.entity.*; import com.voltflow.repository.UserRepository; import com.voltflow.security.JwtService; import lombok.RequiredArgsConstructor; import org.springframework.security.authentication.BadCredentialsException; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;

@Service @RequiredArgsConstructor
public class AuthService {
  private final UserRepository users; private final PasswordEncoder encoder; private final JwtService jwt;
  @Transactional public AuthResponse register(RegisterRequest r){if(users.existsByEmail(r.email().toLowerCase()))throw new IllegalArgumentException("Email is already registered");User u=new User();u.setFullName(r.fullName());u.setEmail(r.email().toLowerCase());u.setPasswordHash(encoder.encode(r.password()));u.setRole(r.role()==null?Role.DRIVER:r.role());users.save(u);return response(u);}
  public AuthResponse login(LoginRequest r){User u=users.findByEmail(r.email().toLowerCase()).orElseThrow(()->new BadCredentialsException("Invalid credentials"));if(!encoder.matches(r.password(),u.getPasswordHash()))throw new BadCredentialsException("Invalid credentials");return response(u);}
  private AuthResponse response(User u){return new AuthResponse(jwt.issue(u.getEmail(),u.getRole().name()),u.getId(),u.getFullName(),u.getEmail(),u.getRole());}
}
