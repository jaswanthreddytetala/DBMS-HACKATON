package com.voltflow.config;

import com.voltflow.entity.Role;
import com.voltflow.entity.User;
import com.voltflow.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DemoDataConfig {
  @Bean
  CommandLineRunner demoUsers(UserRepository users, PasswordEncoder encoder) {
    return args -> {
      create(users, encoder, "Alex Morgan", "admin@voltflow.com", Role.ADMIN);
      create(users, encoder, "Maya Chen", "driver@voltflow.com", Role.DRIVER);
      create(users, encoder, "Jordan Lee", "operator@voltflow.com", Role.OPERATOR);
    };
  }

  private void create(UserRepository users, PasswordEncoder encoder, String name, String email, Role role) {
    if (users.existsByEmail(email)) return;
    User user = new User();
    user.setFullName(name);
    user.setEmail(email);
    user.setPasswordHash(encoder.encode("VoltFlow@2026"));
    user.setRole(role);
    users.save(user);
  }
}
