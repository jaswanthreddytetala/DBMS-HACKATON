package com.voltflow.repository;
import com.voltflow.entity.ChargingStation; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface StationRepository extends JpaRepository<ChargingStation,Long> { List<ChargingStation> findByCityContainingIgnoreCaseOrNameContainingIgnoreCase(String city,String name); }
