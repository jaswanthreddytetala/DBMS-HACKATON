package com.voltflow.exception;
import org.springframework.http.*; import org.springframework.security.authentication.BadCredentialsException; import org.springframework.web.bind.MethodArgumentNotValidException; import org.springframework.web.bind.annotation.*; import java.time.Instant; import java.util.Map;
@RestControllerAdvice
public class ApiExceptionHandler {
  @ExceptionHandler(NotFoundException.class) ResponseEntity<?> notFound(Exception e){return error(HttpStatus.NOT_FOUND,e.getMessage());}
  @ExceptionHandler({IllegalArgumentException.class,IllegalStateException.class,MethodArgumentNotValidException.class}) ResponseEntity<?> bad(Exception e){return error(HttpStatus.BAD_REQUEST,e.getMessage());}
  @ExceptionHandler(BadCredentialsException.class) ResponseEntity<?> denied(Exception e){return error(HttpStatus.UNAUTHORIZED,e.getMessage());}
  private ResponseEntity<?> error(HttpStatus status,String message){return ResponseEntity.status(status).body(Map.of("timestamp",Instant.now(),"status",status.value(),"message",message));}
}
