export const stations = [
  { id: 1, name: "Marina Green Hub", address: "Marina Boulevard, San Francisco", distance: "1.2 mi", available: 8, total: 12, connector: "CCS2 · NACS", speed: "250 kW", price: "$0.39", status: "Available", utilization: 76 },
  { id: 2, name: "Mission Bay Charge", address: "4th Street, San Francisco", distance: "2.8 mi", available: 3, total: 10, connector: "CCS2 · CHAdeMO", speed: "150 kW", price: "$0.34", status: "Busy", utilization: 68 },
  { id: 3, name: "Presidio Power Point", address: "Lincoln Boulevard, San Francisco", distance: "4.1 mi", available: 6, total: 8, connector: "NACS · Type 2", speed: "180 kW", price: "$0.42", status: "Available", utilization: 54 },
  { id: 4, name: "SoMa Energy Deck", address: "Howard Street, San Francisco", distance: "4.7 mi", available: 1, total: 14, connector: "CCS2 · NACS", speed: "350 kW", price: "$0.46", status: "Busy", utilization: 91 },
];

export const energyData = [
  { day: "Mon", energy: 2840, sessions: 122 },
  { day: "Tue", energy: 3210, sessions: 148 },
  { day: "Wed", energy: 2980, sessions: 136 },
  { day: "Thu", energy: 3720, sessions: 171 },
  { day: "Fri", energy: 3980, sessions: 186 },
  { day: "Sat", energy: 3410, sessions: 159 },
  { day: "Sun", energy: 3650, sessions: 168 },
];

export const demandData = [
  { hour: "12am", demand: 18 }, { hour: "4am", demand: 11 }, { hour: "8am", demand: 58 },
  { hour: "12pm", demand: 72 }, { hour: "4pm", demand: 64 }, { hour: "8pm", demand: 88 }, { hour: "11pm", demand: 34 },
];

export const sessions = [
  { car: "Tesla Model 3", station: "Marina Green Hub", time: "Today, 10:24", energy: "42.8 kWh", cost: "$16.69", status: "Charging" },
  { car: "Hyundai Ioniq 5", station: "SoMa Energy Deck", time: "Today, 09:52", energy: "36.2 kWh", cost: "$16.65", status: "Completed" },
  { car: "Ford Mustang Mach-E", station: "Mission Bay Charge", time: "Today, 09:18", energy: "51.4 kWh", cost: "$17.48", status: "Completed" },
  { car: "Rivian R1S", station: "Presidio Power Point", time: "Today, 08:47", energy: "29.6 kWh", cost: "$12.43", status: "Completed" },
];
