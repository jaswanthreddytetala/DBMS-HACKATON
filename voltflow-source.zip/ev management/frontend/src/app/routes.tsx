import { createBrowserRouter, Navigate } from "react-router";
import { AppLayout } from "../layouts/AppLayout";
import { LandingPage } from "../pages/LandingPage";
import { LoginPage } from "../pages/LoginPage";
import { DashboardPage } from "../pages/DashboardPage";
import { StationsPage } from "../pages/StationsPage";
import { AnalyticsPage } from "../pages/AnalyticsPage";
import { BookingsPage } from "../pages/BookingsPage";

export const router = createBrowserRouter([
  { path: "/", Component: LandingPage },
  { path: "/login", Component: LoginPage },
  {
    path: "/app",
    Component: AppLayout,
    children: [
      { index: true, element: <Navigate to="dashboard" replace /> },
      { path: "dashboard", Component: DashboardPage },
      { path: "stations", Component: StationsPage },
      { path: "bookings", Component: BookingsPage },
      { path: "analytics", Component: AnalyticsPage },
      { path: "*", element: <Navigate to="dashboard" replace /> },
    ],
  },
]);
