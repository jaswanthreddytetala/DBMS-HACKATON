import { Activity, BarChart3, Bell, CalendarDays, ChevronDown, LogOut, MapPin, Menu, Settings, Users, Zap } from "lucide-react";
import { NavLink, Outlet, useNavigate } from "react-router";
import { Logo } from "../components/Logo";

const links = [
  { to: "/app/dashboard", label: "Overview", icon: Activity },
  { to: "/app/stations", label: "Stations", icon: MapPin },
  { to: "/app/bookings", label: "Bookings", icon: CalendarDays },
  { to: "/app/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/app/stations", label: "Users", icon: Users },
];

export function AppLayout() {
  const navigate = useNavigate();
  return <div className="min-h-screen bg-slate-50 text-slate-900">
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 border-r border-slate-800 bg-slate-950 p-5 lg:flex lg:flex-col">
      <Logo light />
      <div className="mt-10"><p className="px-3 text-[11px] font-semibold uppercase tracking-widest text-slate-500">Workspace</p><nav className="mt-3 space-y-1">{links.map(({ to, label, icon: Icon }) => <NavLink key={label} to={to} className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${isActive && (label !== "Users" || to.includes(label.toLowerCase())) ? "bg-white/10 text-white" : "text-slate-400 hover:bg-white/5 hover:text-white"}`}><Icon size={18}/>{label}</NavLink>)}</nav></div>
      <div className="mt-auto rounded-2xl border border-emerald-400/20 bg-emerald-400/10 p-4"><div className="mb-3 grid size-9 place-items-center rounded-xl bg-emerald-400 text-slate-950"><Zap size={18}/></div><p className="text-sm font-semibold text-white">Network health</p><p className="mt-1 text-xs leading-5 text-slate-400">All systems operational</p><div className="mt-3 h-1.5 rounded-full bg-white/10"><div className="h-full w-[94%] rounded-full bg-emerald-400"/></div></div>
      <button onClick={() => navigate("/")} className="mt-4 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-400 hover:bg-white/5 hover:text-white"><LogOut size={17}/> Sign out</button>
    </aside>
    <div className="lg:pl-64">
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-slate-200/80 bg-white/90 px-4 backdrop-blur-xl md:px-8"><div className="flex items-center gap-3"><button className="grid size-9 place-items-center rounded-lg border border-slate-200 lg:hidden"><Menu size={18}/></button><div><p className="text-sm font-semibold text-slate-900">Fleet Operations</p><p className="hidden text-xs text-slate-500 sm:block">San Francisco Network</p></div></div><div className="flex items-center gap-2"><button className="relative grid size-10 place-items-center rounded-xl text-slate-500 hover:bg-slate-100"><Bell size={19}/><span className="absolute right-2 top-2 size-2 rounded-full bg-emerald-500 ring-2 ring-white"/></button><button className="flex items-center gap-2 rounded-xl p-1.5 hover:bg-slate-100"><span className="grid size-8 place-items-center rounded-lg bg-slate-900 text-xs font-semibold text-white">AM</span><span className="hidden text-left sm:block"><span className="block text-xs font-semibold">Alex Morgan</span><span className="block text-[11px] text-slate-500">Administrator</span></span><ChevronDown size={14} className="text-slate-400"/></button><button className="hidden size-10 place-items-center rounded-xl text-slate-500 hover:bg-slate-100 md:grid"><Settings size={18}/></button></div></header>
      <main className="mx-auto max-w-[1500px] p-4 md:p-8"><Outlet /></main>
    </div>
  </div>;
}
