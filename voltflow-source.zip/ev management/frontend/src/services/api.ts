import axios from "axios";

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? "http://localhost:8080/api",
  timeout: 10000,
});

api.interceptors.request.use((config) => {
  const token = sessionStorage.getItem("voltflow_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => Promise.reject(new Error(error.response?.data?.message ?? "VoltFlow API is unavailable")),
);

export const authApi = {
  login: (email: string, password: string) => api.post("/auth/login", { email, password }),
  register: (payload: { fullName: string; email: string; password: string; role: string }) => api.post("/auth/register", payload),
};

export const stationApi = {
  list: (query = "") => api.get("/stations", { params: query ? { q: query } : {} }),
  get: (id: number) => api.get(`/stations/${id}`),
  create: (payload: unknown) => api.post("/stations", payload),
  update: (id: number, payload: unknown) => api.put(`/stations/${id}`, payload),
  remove: (id: number) => api.delete(`/stations/${id}`),
};
