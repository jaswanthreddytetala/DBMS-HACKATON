# VoltFlow

**Powering the Future of Electric Mobility.**

VoltFlow is a premium EV charging management platform for network administrators, station operators and drivers. It combines station discovery, reservations, simulated charging sessions, role-aware operations, analytics and optional demand forecasting.

## Project structure

```text
ev management/
├── frontend/                 React, TypeScript, Tailwind, Router, Recharts
│   └── src/
│       ├── app/              Data Router configuration
│       ├── components/       Reusable UI primitives
│       ├── data/             Preview sample data
│       ├── layouts/          Authenticated SaaS shell
│       ├── pages/            Landing, auth, dashboard and workflows
│       └── services/         Axios REST client
├── backend/                  Java 21 / Spring Boot REST API
│   └── src/main/java/com/voltflow/
│       ├── config/           Security, CORS and demo bootstrap
│       ├── controller/       REST endpoints
│       ├── dto/              Validated request records
│       ├── entity/           Normalized JPA domain
│       ├── exception/        API error handling
│       ├── repository/       Spring Data repositories
│       ├── security/         JWT filter and token service
│       └── service/          Transactional business rules
├── database/                 MySQL schema and station fixtures
├── ml-service/               Optional Flask + Random Forest service
└── docs/                     Architecture, API and setup guides
```

## Technology

- **Frontend:** React 19, TypeScript, Tailwind CSS v4, React Router, Recharts, Lucide, Axios, Leaflet/OpenStreetMap
- **Backend:** Java 21, Spring Boot, Spring MVC, Spring Security, Spring Data JPA, Hibernate, Maven
- **Database:** MySQL 8
- **ML:** Python, Flask, Pandas, NumPy, Scikit-learn

## Quick start

See [`docs/setup-guide.md`](docs/setup-guide.md) for complete commands.

1. Import `database/schema.sql`, then `database/sample-data.sql`.
2. Export `DB_PASSWORD` and a 32+ byte `JWT_SECRET`.
3. Run `mvn spring-boot:run` from `backend`.
4. Set `VITE_DEMO_MODE=false` and run `pnpm dev` from `frontend`.
5. Optionally run `python app.py` from `ml-service`.

## Demo accounts

All demo accounts use `VoltFlow@2026`; BCrypt hashes are generated at backend startup.

| Role | Email |
|---|---|
| ADMIN | `admin@voltflow.com` |
| DRIVER | `driver@voltflow.com` |
| OPERATOR | `operator@voltflow.com` |

## Core behavior

- Stateless JWT authentication with BCrypt password hashing
- Role-protected station and charger management
- Booking → charging → completed/cancelled workflow
- Final cost calculated server-side as `energy consumed × station price`
- Responsive dashboards, filtering, booking dialog, simulation and CSV export
- Optional Random Forest service trained on labelled synthetic data

## Known limitations

- Charger actions are a software simulation; no OCPP or physical charger communication is claimed.
- The embedded preview uses realistic fixtures. The Axios service is ready for the Spring API in deployed mode.
- Payments are modeled, but no external payment processor is connected.
- ML is demonstration-grade and must be retrained on production history.
- Production should replace demo accounts and add refresh-token rotation, audit logging, rate limiting and managed secrets.

API details are in [`docs/api-documentation.md`](docs/api-documentation.md).
