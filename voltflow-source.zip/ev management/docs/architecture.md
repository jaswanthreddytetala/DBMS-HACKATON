# VoltFlow Architecture

VoltFlow is split into three independently deployable services.

```text
React + TypeScript SPA
        |
        | HTTPS / JWT
        v
Spring Boot REST API ----> MySQL 8
        |
        | optional HTTP
        v
Python prediction service
```

## Frontend

The React application uses React Router Data mode. Reusable UI lives in `components`, route-level views in `pages`, the authenticated shell in `layouts`, and Axios adapters in `services`. Recharts powers analytics. The station view is prepared for Leaflet/OpenStreetMap; the current investor demo uses a lightweight map treatment so it remains reliable in the embedded preview.

## Backend

The API follows Controller → Service → Repository → MySQL. JPA entities model users, stations, chargers, bookings, sessions, payments, maintenance requests and notifications. Spring Security is stateless: the auth service hashes passwords with BCrypt and issues signed JWTs. Endpoint and method-level authorization enforce ADMIN, DRIVER and OPERATOR boundaries.

Charging remains a software simulation. `SessionService` controls state transitions and computes `energyKwh × station.pricePerKwh`. The charger boundary can later be replaced by an OCPP adapter without changing booking and billing domains.

## ML service

The Flask service is optional and does not block core charging workflows. A Random Forest is trained at startup on explicitly synthetic hourly data and exposes demand and peak-hour predictions.
