# VoltFlow REST API

Base URL: `http://localhost:8080/api`

Protected requests use `Authorization: Bearer <JWT>`.

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/auth/register` | Public | Register and receive JWT |
| POST | `/auth/login` | Public | Authenticate and receive JWT |
| GET | `/stations?q=` | Public | Search stations |
| GET | `/stations/{id}` | Public | Station detail |
| POST | `/stations` | Admin, Operator | Create station |
| PUT | `/stations/{id}` | Admin, Operator | Update station |
| DELETE | `/stations/{id}` | Admin | Delete station |
| GET | `/chargers?stationId=` | Authenticated | List chargers |
| POST | `/chargers?stationId=` | Admin, Operator | Add charger |
| PUT | `/chargers/{id}` | Admin, Operator | Update charger/status |
| POST | `/bookings` | Authenticated | Book charger |
| GET | `/bookings` | Authenticated | List bookings |
| PUT | `/bookings/{id}/cancel` | Authenticated | Cancel booking |
| POST | `/sessions/start` | Authenticated | Start simulated charging |
| POST | `/sessions/{id}/stop` | Authenticated | Stop and calculate cost |
| GET | `/sessions` | Authenticated | Session history |
| GET | `/analytics/overview` | Authenticated | Network KPIs |
| GET | `/analytics/energy` | Authenticated | Energy series |
| GET | `/analytics/revenue` | Authenticated | Revenue series |
| GET/PUT/DELETE | `/users[/{id}]` | Admin | Manage users |

## Examples

```json
POST /api/auth/login
{"email":"admin@voltflow.com","password":"VoltFlow@2026"}
```

```json
POST /api/bookings
{"chargerId":1,"scheduledAt":"2026-03-10T09:30:00Z"}
```

```json
POST /api/sessions/1/stop
{"energyKwh":42.8}
```

Errors use a stable `{ timestamp, status, message }` shape and appropriate HTTP status codes.
