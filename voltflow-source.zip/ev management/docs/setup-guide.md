# Setup Guide

## Prerequisites

- Node.js 22+, pnpm 10+
- Java 21 and Maven 3.9+
- MySQL 8+
- Python 3.11+ (optional)

## Database

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/sample-data.sql
```

Create a dedicated MySQL user and grant it privileges only on `voltflow`. Never commit its password.

## Backend

```bash
cd backend
cp .env.example .env
export DB_PASSWORD='your-password'
export JWT_SECRET='a-secret-of-at-least-32-bytes'
mvn spring-boot:run
```

The API starts on port 8080. `DDL_AUTO=validate` ensures that JPA and the SQL schema agree.

## Frontend

```bash
cd frontend
cp .env.example .env
pnpm install
pnpm dev
```

The embedded Figma Make preview is bridged to this source from the repository-level Vite entry. A standalone checkout uses the frontend package directly.

## Optional ML service

```bash
cd ml-service
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

The prediction API starts on port 5001.
