CREATE DATABASE IF NOT EXISTS voltflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE voltflow;

CREATE TABLE users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('ADMIN','DRIVER','OPERATOR') NOT NULL DEFAULT 'DRIVER',
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_role (role)
);
CREATE TABLE charging_stations (
  id BIGINT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, address VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL, latitude DECIMAL(10,7) NOT NULL, longitude DECIMAL(10,7) NOT NULL,
  price_per_kwh DECIMAL(10,2) NOT NULL, operating_hours VARCHAR(255) NOT NULL DEFAULT '24/7',
  available BOOLEAN NOT NULL DEFAULT TRUE, operator_id BIGINT NULL,
  CONSTRAINT fk_station_operator FOREIGN KEY(operator_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_station_city(city), INDEX idx_station_coordinates(latitude,longitude)
);
CREATE TABLE chargers (
  id BIGINT PRIMARY KEY AUTO_INCREMENT, code VARCHAR(30) NOT NULL, connector_type VARCHAR(30) NOT NULL,
  power_kw DECIMAL(8,2) NOT NULL, status ENUM('AVAILABLE','OCCUPIED','OFFLINE','MAINTENANCE') NOT NULL,
  station_id BIGINT NOT NULL, CONSTRAINT fk_charger_station FOREIGN KEY(station_id) REFERENCES charging_stations(id) ON DELETE CASCADE,
  CONSTRAINT uk_station_charger_code UNIQUE(station_id,code), INDEX idx_charger_status(status)
);
CREATE TABLE bookings (
  id BIGINT PRIMARY KEY AUTO_INCREMENT, driver_id BIGINT NOT NULL, charger_id BIGINT NOT NULL,
  scheduled_at TIMESTAMP NOT NULL, status ENUM('BOOKED','CHARGING','COMPLETED','CANCELLED') NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(driver_id) REFERENCES users(id), FOREIGN KEY(charger_id) REFERENCES chargers(id),
  INDEX idx_booking_driver(driver_id), INDEX idx_booking_start(scheduled_at)
);
CREATE TABLE charging_sessions (
  id BIGINT PRIMARY KEY AUTO_INCREMENT, booking_id BIGINT UNIQUE, driver_id BIGINT NOT NULL, charger_id BIGINT NOT NULL,
  started_at TIMESTAMP NOT NULL, ended_at TIMESTAMP NULL, energy_kwh DECIMAL(10,3) NOT NULL DEFAULT 0,
  total_cost DECIMAL(10,2) NOT NULL DEFAULT 0, status ENUM('BOOKED','CHARGING','COMPLETED','CANCELLED') NOT NULL,
  FOREIGN KEY(booking_id) REFERENCES bookings(id), FOREIGN KEY(driver_id) REFERENCES users(id), FOREIGN KEY(charger_id) REFERENCES chargers(id),
  INDEX idx_session_status(status), INDEX idx_session_started(started_at)
);
CREATE TABLE payments (
  id BIGINT PRIMARY KEY AUTO_INCREMENT, session_id BIGINT NOT NULL UNIQUE, amount DECIMAL(10,2) NOT NULL,
  status VARCHAR(20) NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(session_id) REFERENCES charging_sessions(id)
);
CREATE TABLE maintenance_requests (
  id BIGINT PRIMARY KEY AUTO_INCREMENT, charger_id BIGINT NOT NULL, description VARCHAR(255) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'OPEN', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(charger_id) REFERENCES chargers(id)
);
CREATE TABLE notifications (
  id BIGINT PRIMARY KEY AUTO_INCREMENT, user_id BIGINT NOT NULL, message VARCHAR(255) NOT NULL,
  read_flag BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id), INDEX idx_notification_user(user_id)
);
